class Posicion (var fila: Int, var columna: Int) {



}