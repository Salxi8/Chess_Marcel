open class Ficha (val blanca_o_negra: Boolean, val posicionFicha: Posicion){



}