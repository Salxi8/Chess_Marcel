class Tablero {

    val tablero : List<ArrayList<Ficha?>>

    val numFilas = 8;
    val numColumnas = 8;


    init {
        val tablero = arrayListOf(arrayListOf<Ficha?>())
        val letrasTablero = listOf<Char>('A', 'B', 'C', 'D', 'E', 'F', 'G', 'H') // PREGUNTAR QUE ES MILLOR

        for(i in 0..numFilas - 1){ // AÑADO DOS MAS PARAS PODER MOSTRAR POR PANTALLA LAS LETRAS Y LOS NÚMEROS DEL TABLERO
            tablero.add(arrayListOf())
            for(j in 0..numColumnas - 1){
                // ====================================
                // CREO TODOS LOS CONTORNOS DEL TABLERO
                /*if (i == 0){
                    if(j == 0 || j == numColumnas + 1)
                        print("  ")
                    else
                        print("·${'A'+ (j - 1)} ")
                }
                else if (i == numFilas + 1){
                    if(j == 0 || j == numColumnas + 1)
                        print("  ")
                    else
                        print("·${'A'+ (j - 1)} ")
                }
                else if (j == 0){
                    print("$i ")
                }
                else if (j == numColumnas + 1){
                    print("$i ")
                }*/
                // ====================================
                // CREO LAS FICHAS DEL TABLERO
                if (i == 1){
                    tablero[i].add(Peon(true, Posicion(i, j))) // PEON BLANCO
                }
                else if (i == 6){
                    tablero[i].add(Peon(false, Posicion(i, j))) // PEON NEGRO
                }
                else if(i == 0 && (j == 0 || j == 7)){
                    tablero[i].add(Torre(true, Posicion(i, j))) // TORRE BLANCA
                }
                else if(i == 7 && (j == 0 || j == 7)){
                    tablero[i].add(Torre(false, Posicion(i, j))) // TORRE NEGRA
                }
                else {
                    tablero[i].add(null)

                }

            }
            println()
        }

        this.tablero = tablero
    }


    operator fun get(i: Int, j: Int): Ficha? {
        return tablero[i][j]
    }


    fun actualizarTablero(turnoBlancoNegro: Boolean) {

        // APUNTES: MIRAR SI ESTO SE PUEDE HACER EN OTRA FUNCIÓN PRIVADA

        var posInicialY = 0
        var posInicialX = 0

        do { // COMPRUEBO QUE HAYA UNA FICHA EN LA CASILLA
            print("En que FILA se encuentra la FICHA que desea MOVER: ")
            posInicialY = readln().toInt()
            print("En que COLUMNA se encuentra la FICHA que desea MOVER: ")
            posInicialX = readln().toInt()

        }while(tablero[posInicialY][posInicialX] !is Ficha || (tablero[posInicialY][posInicialX]?.blanca_o_negra  != turnoBlancoNegro))

        // =============================================================

        if (tablero[posInicialY][posInicialX] is Peon){

            tablero[posInicialY][posInicialX] = null // POSICIÓN DONDE SE ENCONTRABA LA PIEZA QUEDA NULLA

            if (turnoBlancoNegro) {

                val peonAux = Peon(true, Posicion(posInicialY, posInicialX))

                peonAux.movimientoPeon(peonAux, this) // LA FUNCION NECESITA RETORNAR UN PEON?????????
                // PODER TIRAR ATRAS SI NOS HEMOS EQUIVOCADO DE FICHA O QUE DIRECTAMENTE EL SISTEMA TE DIGA QUE ESA FICHA
                // NO SE PUEDE MOVER A NINGUN LADO

                tablero[peonAux.posicionFicha.fila][peonAux.posicionFicha.columna] = peonAux
            }
            else{

                val peonAux = Peon(false, Posicion(posInicialY, posInicialX))

                peonAux.movimientoPeon(peonAux, this)
                // PODER TIRAR ATRAS SI NOS HEMOS EQUIVOCADO DE FICHA O QUE DIRECTAMENTE EL SISTEMA TE DIGA QUE ESA FICHA
                // NO SE PUEDE MOVER A NINGUN LADO

                tablero[peonAux.posicionFicha.fila][peonAux.posicionFicha.columna] = peonAux
            }
            // SI PEON ES NEGRO
        }
    }

    fun printarTabero() {


        for(i in 0..numFilas - 1){ // AÑADO DOS MAS PARAS PODER MOSTRAR POR PANTALLA LAS LETRAS Y LOS NÚMEROS DEL TABLERO
            for(j in 0..numColumnas - 1){

                // CREO LAS FICHAS DEL TABLERO
                if (tablero[i][j] is Peon){
                    if ((tablero[i][j]?.blanca_o_negra) == true)
                        print("♙ ")
                    else
                        print("♟ ")
                }
                else if (tablero[i][j] is Torre){
                    if ((tablero[i][j]?.blanca_o_negra) == true)
                        print("♖ ")
                    else
                        print("♜ ")
                }
                else {
                    print(" ■ ")
                }

            }
            println()
        }


    }

}